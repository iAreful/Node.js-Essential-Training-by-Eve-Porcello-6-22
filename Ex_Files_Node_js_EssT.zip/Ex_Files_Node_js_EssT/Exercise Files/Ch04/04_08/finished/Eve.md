Question Answers for Eve
========
Question: What is your name?
Answer: Eve
Question: What would you rather be doing?
Answer: Skiing
Question: What is your preferred programming language?
Answer: JavaScript
