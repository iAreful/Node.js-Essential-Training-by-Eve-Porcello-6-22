This is a New File
==================

    ES6 Template Strings are cool. They honor whitespace.

    * Template Strings
    * Node File System
    * Readline CLIs

### Node.js Everyone!
