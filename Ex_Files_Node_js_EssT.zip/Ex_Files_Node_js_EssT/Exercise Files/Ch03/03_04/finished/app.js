const { inc, dec, getCount } = require("./myModule");

inc();
inc();
inc();

console.log(`the count is ${getCount()}`);
